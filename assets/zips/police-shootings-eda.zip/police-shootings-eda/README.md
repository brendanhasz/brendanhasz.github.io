# police-shootings-eda

This repository contains a jupyter notebook with an exploratory data analysis of the the [Washington Post's fatal police shooting dataset](https://www.washingtonpost.com/graphics/2018/national/police-shootings-2018/).
