# Nice Ride MN Bike Share EDA

This repository contains a Jupyter notebook analyzing Nice Ride MN's public Bike Share data.

